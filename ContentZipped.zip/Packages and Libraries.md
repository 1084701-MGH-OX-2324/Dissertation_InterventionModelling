# Dissertation_InterventionModelling
Scripts and Data for the Dissertation: Revisiting the Impact of Targeted vs. Blanket Non-Pharmaceutical Intervention Strategies in the Early Stages of Epidemic Outbreaks


Packages needed: install.packages(c("deSolve", "readxl", "viridis", "dplyr", "openxlsx", "stringr", "ggplot2", "reshape2", "pracma", "patchwork", "gridExtra", "lattice", "ggsci", "ggalluvial", "tidyr", "readr", "kableExtra"))


Required R Libraries:
The necessary libraries are always included into the script.

- deSolve
- readxl
- viridis
- dplyr
- openxlsx
- stringr
- ggplot2
- reshape2
- pracma
- patchwork
- gridExtra
- grid
- lattice
- ggsci
- ggalluvial
- tidyr
- readr
- kableExtra





